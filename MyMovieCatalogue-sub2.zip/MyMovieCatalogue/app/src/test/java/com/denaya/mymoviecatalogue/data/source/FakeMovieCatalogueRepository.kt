package com.denaya.mymoviecatalogue.data.source

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import com.denaya.mymoviecatalogue.data.source.local.entity.Movie
import com.denaya.mymoviecatalogue.data.source.local.entity.TvShow
import com.denaya.mymoviecatalogue.data.source.remote.RemoteDataSource
import com.denaya.mymoviecatalogue.data.source.remote.response.MovieResponse
import com.denaya.mymoviecatalogue.data.source.remote.response.TvShowResponse

class FakeMovieCatalogueRepository (private val remoteDataSource: RemoteDataSource) : MovieCatalogueDataSource {

    override fun getAllMovies(): LiveData<List<Movie>> {
        val movieResults = MutableLiveData<List<Movie>>()
        remoteDataSource.getMovie(object : RemoteDataSource.LoadMoviesCallback {
            override fun onMoviesReceived(movieResponse: List<MovieResponse>) {
                val movieList = ArrayList<Movie>()
                for (response in movieResponse) {
                    val movie = Movie(response.movieId,
                        response.movieTitle,
                        response.movieDesc,
                        response.moviePoster,
                        response.movieRate)
                    movieList.add(movie)
                }
                movieResults.postValue(movieList)
            }
        })

        return movieResults
    }

    override fun getMovieById(movieId: Int): LiveData<Movie> {
        val movieResult = MutableLiveData<Movie>()
        remoteDataSource.getMovie(object : RemoteDataSource.LoadMoviesCallback {
            override fun onMoviesReceived(movieResponse: List<MovieResponse>) {
                lateinit var movie: Movie
                for (response in movieResponse) {
                    if (response.movieId == movieId) {
                        movie = Movie(response.movieId,
                            response.movieTitle,
                            response.movieDesc,
                            response.moviePoster,
                            response.movieRate)
                    }
                }
                movieResult.postValue(movie)
            }
        })

        return movieResult
    }

    override fun getAllTvShows(): LiveData<List<TvShow>> {
        val tvShowResults = MutableLiveData<List<TvShow>>()
        remoteDataSource.getTvShow(object : RemoteDataSource.LoadTvShowsCallback {
            override fun onTvShowsReceived(tvShowResponse: List<TvShowResponse>) {
                val tvList = ArrayList<TvShow>()
                for (response in tvShowResponse) {
                    val tvShow = TvShow(response.showId,
                        response.showTitle,
                        response.showDescription,
                        response.showEpisode,
                        response.showPoster)

                    tvList.add(tvShow)
                }
                tvShowResults.postValue(tvList)
            }
        })
        return tvShowResults
    }

    override fun getTvShowById(tvShowId: Int): LiveData<TvShow> {
        val tvShowResult = MutableLiveData<TvShow>()
        remoteDataSource.getTvShow(object : RemoteDataSource.LoadTvShowsCallback {
            override fun onTvShowsReceived(tvShowResponse: List<TvShowResponse>) {
                lateinit var tvShow: TvShow
                for (response in tvShowResponse) {
                    if (response.showId == tvShowId) {
                        tvShow = TvShow(response.showId,
                            response.showTitle,
                            response.showDescription,
                            response.showEpisode,
                            response.showPoster)
                    }
                }
                tvShowResult.postValue(tvShow)
            }
        })

        return tvShowResult
    }
}