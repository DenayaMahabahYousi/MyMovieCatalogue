package com.denaya.mymoviecatalogue.ui.tvshow

import androidx.arch.core.executor.testing.InstantTaskExecutorRule
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.Observer
import com.denaya.mymoviecatalogue.data.source.MovieCatalogueRepository
import com.denaya.mymoviecatalogue.data.source.local.entity.TvShow
import com.denaya.mymoviecatalogue.ui.tvshow.TvShowViewModel
import com.denaya.mymoviecatalogue.utils.DataDummy
import org.junit.Test

import org.junit.Assert.*
import org.junit.Before
import org.junit.Rule
import org.junit.runner.RunWith
import org.mockito.Mock
import org.mockito.Mockito
import org.mockito.junit.MockitoJUnitRunner

@RunWith(MockitoJUnitRunner::class)
class TvShowViewModelTest {

    private lateinit var viewModel: TvShowViewModel
    private val dummyTvShow = DataDummy.generateTvShows()[0]
    private val tvShowId = dummyTvShow.showId

    @get:Rule
    var instantTaskExecutorRule = InstantTaskExecutorRule()

    @Mock
    private lateinit var movieCatalogueRepository: MovieCatalogueRepository

    @Mock
    private lateinit var observer: Observer<List<TvShow>>

    @Mock
    private lateinit var tvObserver: Observer<TvShow>

    @Before
    fun setUp() {
        viewModel = TvShowViewModel(movieCatalogueRepository)
        viewModel.setSelectedTvShow(tvShowId)
    }

    @Test
    fun getTvShowById() {
        val tvShow = MutableLiveData<TvShow>()
        tvShow.value = dummyTvShow

        Mockito.`when`(movieCatalogueRepository.getTvShowById(tvShowId)).thenReturn(tvShow)
        val tvShowEntity = viewModel.getTvShow().value as TvShow
        Mockito.verify(movieCatalogueRepository).getTvShowById(tvShowId)
        assertNotNull(tvShowEntity)
        assertEquals(dummyTvShow.showId, tvShowEntity.showId)
        assertEquals(dummyTvShow.showTitle, tvShowEntity.showTitle)
        assertEquals(dummyTvShow.showDescription, tvShowEntity.showDescription)
        assertEquals(dummyTvShow.showPoster, tvShowEntity.showPoster)
        assertEquals(dummyTvShow.showEpisode, tvShowEntity.showEpisode)

        viewModel.getTvShow().observeForever(tvObserver)
        Mockito.verify(tvObserver).onChanged(dummyTvShow)
    }

    @Test
    fun getAllTvShows() {
        val dummyTvShows = DataDummy.generateTvShows()
        val tvShows = MutableLiveData<List<TvShow>>()
        tvShows.value = dummyTvShows

        Mockito.`when`(movieCatalogueRepository.getAllTvShows()).thenReturn(tvShows)
        val tvShowEntities = viewModel.getAllTvShows().value
        Mockito.verify(movieCatalogueRepository).getAllTvShows()
        assertNotNull(tvShowEntities)
        assertEquals(10, tvShowEntities?.size)

        viewModel.getAllTvShows().observeForever(observer)
        Mockito.verify(observer).onChanged(dummyTvShows)
    }
}