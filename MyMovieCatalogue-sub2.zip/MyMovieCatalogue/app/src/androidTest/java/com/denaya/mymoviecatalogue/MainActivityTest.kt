package com.denaya.mymoviecatalogue

import androidx.recyclerview.widget.RecyclerView
import androidx.test.core.app.ActivityScenario
import androidx.test.espresso.Espresso.onView
import androidx.test.espresso.IdlingRegistry
import androidx.test.espresso.action.ViewActions.click
import androidx.test.espresso.assertion.ViewAssertions.matches
import androidx.test.espresso.matcher.ViewMatchers.*
import androidx.test.espresso.contrib.RecyclerViewActions
import androidx.test.internal.runner.junit4.AndroidJUnit4ClassRunner
import com.denaya.mymoviecatalogue.utils.DataDummy
import com.denaya.mymoviecatalogue.utils.EspressoIdlingResource
import org.junit.After
import org.junit.Test

import org.junit.Before
import org.junit.runner.RunWith

class MainActivityTest {

    private val dummyMovie = DataDummy.generateMovies()
    private val dummyTvShow = DataDummy.generateTvShows()

    @Before
    fun setup(){
        ActivityScenario.launch(MainActivity::class.java)
        IdlingRegistry.getInstance().register(EspressoIdlingResource.idlingResource)
    }

    @After
    fun tearDown() {
        IdlingRegistry.getInstance().unregister(EspressoIdlingResource.idlingResource)
    }

    @Test
    fun loadMovie() {
        onView(withText("Movies")).perform(click())
        onView(withId(R.id.rv_movies)).check(matches(isDisplayed()))
        onView(withId(R.id.rv_movies)).perform(RecyclerViewActions.scrollToPosition<RecyclerView.ViewHolder>(dummyMovie.size))
    }

    @Test
    fun loadDetailMovie() {
        onView(withText("Movies")).perform(click())
        onView(withId(R.id.rv_movies)).perform(RecyclerViewActions.actionOnItemAtPosition<RecyclerView.ViewHolder>(0, click()))
        onView(withId(R.id.movie_title)).check(matches(isDisplayed()))
        onView(withId(R.id.movie_title)).check(matches(withText(dummyMovie[0].movieTitle)))
        onView(withId(R.id.movie_rate)).check(matches(isDisplayed()))
        onView(withId(R.id.movie_rate)).check(matches(withText(dummyMovie[0].movieRate)))
        onView(withId(R.id.movie_description)).check(matches(isDisplayed()))
        onView(withId(R.id.movie_description)).check(matches(withText(dummyMovie[0].movieDescription)))
        onView(withId(R.id.btn_share)).perform(click())
    }

    @Test
    fun loadTvShow() {
        onView(withText("TV Shows")).perform(click())
        onView(withId(R.id.rv_tv_shows)).check(matches(isDisplayed()))
        onView(withId(R.id.rv_tv_shows)).perform(RecyclerViewActions.scrollToPosition<RecyclerView.ViewHolder>(dummyTvShow.size))
    }

    @Test
    fun loadDetailTvShow() {
        onView(withText("TV Shows")).perform(click())
        onView(withId(R.id.rv_tv_shows)).perform(RecyclerViewActions.actionOnItemAtPosition<RecyclerView.ViewHolder>(0, click()))
        onView(withId(R.id.show_title)).check(matches(isDisplayed()))
        onView(withId(R.id.show_title)).check(matches(withText(dummyTvShow[0].showTitle)))
        onView(withId(R.id.show_eps)).check(matches(isDisplayed()))
        onView(withId(R.id.show_eps)).check(matches(withText(dummyTvShow[0].showEpisode)))
        onView(withId(R.id.show_description)).check(matches(isDisplayed()))
        onView(withId(R.id.show_description)).check(matches(withText(dummyTvShow[0].showDescription)))
    }
}