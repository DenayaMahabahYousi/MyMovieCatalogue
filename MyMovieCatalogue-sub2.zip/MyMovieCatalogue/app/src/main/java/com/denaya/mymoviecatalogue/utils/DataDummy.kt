package com.denaya.mymoviecatalogue.utils

import com.denaya.mymoviecatalogue.R
import com.denaya.mymoviecatalogue.data.source.local.entity.Movie
import com.denaya.mymoviecatalogue.data.source.local.entity.TvShow
import com.denaya.mymoviecatalogue.data.source.remote.response.MovieResponse
import com.denaya.mymoviecatalogue.data.source.remote.response.TvShowResponse

object DataDummy {
    fun generateMovies(): ArrayList<Movie>{
        val movies = ArrayList<Movie>()

        movies.add(Movie(
            1,
            "Avengers: Infinity War (2018)",
            "Iron Man, Thor, the Hulk and the rest of the Avengers unite to battle their most powerful enemy yet -- the evil Thanos. On a mission to collect all six Infinity Stones, Thanos plans to use the artifacts to inflict his twisted will on reality. The fate of the planet and existence itself has never been more uncertain as everything the Avengers have fought for has led up to this moment.",
            "https://www.themoviedb.org/t/p/w1280/7WsyChQLEftFiDOVTGkv3hFpyyt.jpg",
            "8.4/10"))

        movies.add(Movie(
            2,
            "Mary Queen of Scots (2018)",
            "Queen of France at 16 and widowed at 18, Mary Stuart defies pressure to remarry. Instead, she returns to her native Scotland to reclaim her rightful throne. However, Scotland and England fall under the rule of the compelling Elizabeth I. Each young Queen beholds her sister in fear and fascination. Rivals in power and in love, and female regents in a masculine world, the two must decide how to play the game of marriage versus independence.",
            "https://www.themoviedb.org/t/p/w1280/b5RMzLAyq5QW6GtN9sIeAEMLlBI.jpg",
            "6.2/10"))

        movies.add(Movie(
            3,
            "Master Z: Ip Man Legacy (2018)",
            "Defeated by Master Ip, martial arts expert Cheung Tin Chi tries to lead a normal life in Hong Kong until triad leaders draw him back into fighting.",
            "https://www.themoviedb.org/t/p/w1280/6VxEvOF7QDovsG6ro9OVyjH07LF.jpg",
            "6.5/10"))

        movies.add(Movie(
            4,
            "Mortal Engines (2018)",
            "In a post-apocalyptic world where cities move and consume each other to survive, two strangers come together to stop a sinister and destructive conspiracy.",
            "https://www.themoviedb.org/t/p/w1280/gLhYg9NIvIPKVRTtvzCWnp1qJWG.jpg",
            "2.9/10"))

        movies.add(Movie(
            5,
            "Overlord (2018)",
            "On the eve of D-Day, American paratroopers drop behind enemy lines to penetrate the walls of a fortified church and destroy a radio transmitter. As the soldiers approach their target, they soon begin to realize that there's more going on in the Nazi-occupied village than a simple military operation. Making their way to an underground lab, the outnumbered men stumble upon a sinister experiment that forces them into a vicious battle against an army of the undead.",
            "https://www.themoviedb.org/t/p/w600_and_h900_bestv2/l76Rgp32z2UxjULApxGXAPpYdAP.jpg",
            "7.9/10"))

        movies.add(Movie(
            6,
            "Ralph Breaks the Internet (2018)",
            "Video game bad guy Ralph and fellow misfit Vanellope von Schweetz must risk it all by traveling to the World Wide Web in search of a replacement part to save Vanellope's video game, \"Sugar Rush.\" In way over their heads, Ralph and Vanellope rely on the citizens of the internet -- the netizens -- to help navigate their way, including an entrepreneur named Yesss, who is the head algorithm and the heart and soul of trend-making site BuzzzTube.",
            "https://www.themoviedb.org/t/p/w1280/44cb3fCGKUaSxxIjI2ejrgeYfye.jpg",
            "8.8/10"))

        movies.add(Movie(
            7,
            "Robin Hood (2018)",
            "After returning home to England, aristocrat Robin of Loxley learns that the evil Sheriff of Nottingham has seized his family estate. He soon joins forces with Friar Tuck and Little John -- a fierce Arabian warrior who wants to put an end to the Crusades. Armed with arrows and dubbed Robin Hood, Loxley leads a band of oppressed rebels in a daring plan to rob the Sheriff of his money and take away his power.",
            "https://www.themoviedb.org/t/p/w600_and_h900_bestv2/AiRfixFcfTkNbn2A73qVJPlpkUo.jpg",
            "5.3/10"))

        movies.add(Movie(
            8,
            "Serenity (2019)",
            "Baker Dill is a fishing boat captain who leads tours off of the tranquil enclave of Plymouth Island. His peaceful life is soon shattered when his ex-wife Karen tracks him down. Desperate for help, Karen begs Baker to save her -- and their young son -- from her abusive husband. She wants him to take the brute out for a fishing excursion -- then throw him overboard to the sharks. Thrust back into a life that he wanted to forget, Baker now finds himself struggling to choose between right and wrong.",
            "https://www.themoviedb.org/t/p/w600_and_h900_bestv2/hgWAcic93phg4DOuQ8NrsgQWiqu.jpg",
            "5.4/10"))

        movies.add(Movie(
            9,
            "Spider-Man: Into the Spider-Verse (2018)",
            "Bitten by a radioactive spider in the subway, Brooklyn teenager Miles Morales suddenly develops mysterious powers that transform him into the one and only Spider-Man. When he meets Peter Parker, he soon realizes that there are many others who share his special, high-flying talents. Miles must now use his newfound skills to battle the evil Kingpin, a hulking madman who can open portals to other universes and pull different versions of Spider-Man into our world.",
            "https://www.themoviedb.org/t/p/w600_and_h900_bestv2/nyXfGIkJQgKhugxMVql15URobtt.jpg",
            "9.7/10"))

        movies.add(Movie(
            10,
            "T-34 (2019)",
            "When a group of Russian soldiers are captured by the Nazis during World War II, they band together to plot and carry out a daring escape mission.",
            "https://www.themoviedb.org/t/p/w600_and_h900_bestv2/jqBIHiSglRfNxjh1zodHLa9E7zW.jpg",
            "6.7/10"))

        return movies
    }

    fun generateTvShows(): ArrayList<TvShow>{
        val shows = ArrayList<TvShow>()

        shows.add(TvShow(
            1,
            "Iron Fist (season 1)",
            "Fueled by a desire for revenge, nine-year-old Danny Rand spent a decade training in martial arts in the heavenly city of K'un-Lun. He eventually earned the title of Iron Fist, granting him even more power. Instead of staying and embracing immortality, he returned to Earth ten years later to avenge his dead parents.",
            "13",
            "https://www.themoviedb.org/t/p/w600_and_h900_bestv2/4l6KD9HhtD6nCDEfg10Lp6C6zah.jpg"
        ))

        shows.add(TvShow(
            2,
            "Naruto: Shippuden (season 1)",
            "Naruto Uzumaki, Sakura Haruno and Sai reuniting with Sasuke Uchiha who seeks Naruto's power and suppresses the Nine-Tailed Fox within his subconscious. The first episode begins with Naruto returning home after two and a half years of training with Jiraiya, and seeing Sakura and Konohamaru, many people from the village congratulate him. Konohamaru and his fellows are on a mission and somehow successfully complete it. Jiraiya accompanies Naruto home and meets Tsunade who assigns Naruto and Sakura on their first mission, but first they must defeat someone to prove their growth and progress in the last two and a half years.",
            "32",
            "https://www.themoviedb.org/t/p/w600_and_h900_bestv2/zAYRe2bJxpWTVrwwmBc00VFkAf4.jpg"
        ))

        shows.add(TvShow(
            3,
            "NCIS (series)",
            "NCIS is an American police procedural drama television series, revolving around a fictional team of special agents from the Naval Criminal Investigative Service, which conducts criminal investigations involving the U.S. Navy and Marine Corps.",
            "412",
            "https://www.themoviedb.org/t/p/w600_and_h900_bestv2/fi8EvaWtL5CvoielOjjVvTr7ux3.jpg"
        ))

        shows.add(TvShow(
            4,
            "Riverdale",
            "Archie Andrews discovers his love for music, and his teacher. ... After a teenager was murdered within the town of Riverdale, a group of teenagers, the jock Archie, the girl next door Betty, the new girl Veronica and the outcast Jughead try to unravel the evils lurking within this seemingly innocent town.",
            "13",
            "https://www.themoviedb.org/t/p/w600_and_h900_bestv2/wRbjVBdDo5qHAEOVYoMWpM58FSA.jpg"
        ))

        shows.add(TvShow(
            5,
            "Shameless",
            "The first season of Shameless depicts the dysfunctional family of Frank Gallagher, a single, alcoholic, trashy father of six children in Chicago, Illinois. ... Often involved in the Gallagher's lives are their neighbors, Kevin and Veronica, who fake a marriage mid-season to obtain a substantial dowry.",
            "134",
            "https://www.themoviedb.org/t/p/w600_and_h900_bestv2/9akij7PqZ1g6zl42DQQTtL9CTSb.jpg"
        ))

        shows.add(TvShow(
            6,
            "Supergirl",
            "Kara Zor-El was sent to Earth from Krypton as a thirteen year old by her parents Zor-El and Alura. ... The series begins eleven years later when Kara is learning to embrace her own superhuman powers as a Kryptonian and has adopted the superheroine alias \"Supergirl\".",
            "113",
            "https://www.themoviedb.org/t/p/w600_and_h900_bestv2/zsaiq8ZclPuneuN7loLEbsh1ANJ.jpg"
        ))

        shows.add(TvShow(
            7,
            "Supernatural",
            "Supernatural is an American television series created by Eric Kripke. ... Starring Jared Padalecki as Sam Winchester and Jensen Ackles as Dean Winchester, the series follows the two brothers as they hunt demons, ghosts, monsters, and other supernatural beings.",
            "327",
            "https://www.themoviedb.org/t/p/w600_and_h900_bestv2/KoYWXbnYuS3b0GyQPkbuexlVK9.jpg"
        ))

        shows.add(TvShow(
            8,
            "The Simpsons",
            "The series is a satirical depiction of American life, epitomized by the Simpson family, which consists of Homer, Marge, Bart, Lisa, and Maggie. The show is set in the fictional town of Springfield and parodies American culture and society, television, and the human condition.",
            "703",
            "https://www.themoviedb.org/t/p/w600_and_h900_bestv2/zLudbPueg8CxGhMS2tyDh3p0TdK.jpg"
        ))

        shows.add(TvShow(
            9,
            "The Umbrella Academy",
            "A family of former child heroes, now grown apart, must reunite to continue to protect the world. ... Seven are adopted by Sir Reginald Hargreeves, a billionaire industrialist, who creates The Umbrella Academy and prepares his \"children\" to save the world. But not everything went according to plan.",
            "20",
            "https://www.themoviedb.org/t/p/w600_and_h900_bestv2/scZlQQYnDVlnpxFTxaIv2g0BWnL.jpg"
        ))

        shows.add(TvShow(
            10,
            "The Walking Dead",
            "The Walking Dead takes place after the onset of a worldwide zombie apocalypse. ... The series centers on sheriff's deputy Rick Grimes, who wakes up from a coma. While in a coma, the world has been taken over by walkers.",
            "153",
            "https://www.themoviedb.org/t/p/w600_and_h900_bestv2/rqeYMLryjcawh2JeRpCVUDXYM5b.jpg"
        ))


        return shows
    }

    fun generateRemoteDummyMovies(): List<MovieResponse> {
        val rMovies = ArrayList<MovieResponse>()

        rMovies.add(
            MovieResponse(
                1,
                "Avengers: Infinity War (2018)",
                "Iron Man, Thor, the Hulk and the rest of the Avengers unite to battle their most powerful enemy yet -- the evil Thanos. On a mission to collect all six Infinity Stones, Thanos plans to use the artifacts to inflict his twisted will on reality. The fate of the planet and existence itself has never been more uncertain as everything the Avengers have fought for has led up to this moment.",
                "https://www.themoviedb.org/t/p/w1280/7WsyChQLEftFiDOVTGkv3hFpyyt.jpg",
                "8.4/10"
            )
        )

        rMovies.add(
            MovieResponse(
                2,
                "Mary Queen of Scots (2018)",
                "Queen of France at 16 and widowed at 18, Mary Stuart defies pressure to remarry. Instead, she returns to her native Scotland to reclaim her rightful throne. However, Scotland and England fall under the rule of the compelling Elizabeth I. Each young Queen beholds her sister in fear and fascination. Rivals in power and in love, and female regents in a masculine world, the two must decide how to play the game of marriage versus independence.",
                "https://www.themoviedb.org/t/p/w1280/b5RMzLAyq5QW6GtN9sIeAEMLlBI.jpg",
                "6.2/10"
            )
        )

        rMovies.add(
            MovieResponse(
                3,
                "Master Z: Ip Man Legacy (2018)",
                "Defeated by Master Ip, martial arts expert Cheung Tin Chi tries to lead a normal life in Hong Kong until triad leaders draw him back into fighting.",
                "https://www.themoviedb.org/t/p/w1280/6VxEvOF7QDovsG6ro9OVyjH07LF.jpg",
                "6.5/10"
            )
        )

        rMovies.add(
            MovieResponse(
                4,
                "Mortal Engines (2018)",
                "In a post-apocalyptic world where cities move and consume each other to survive, two strangers come together to stop a sinister and destructive conspiracy.",
                "https://www.themoviedb.org/t/p/w1280/gLhYg9NIvIPKVRTtvzCWnp1qJWG.jpg",
                "2.9/10"
            )
        )

        rMovies.add(
            MovieResponse(
                5,
                "Overlord (2018)",
                "On the eve of D-Day, American paratroopers drop behind enemy lines to penetrate the walls of a fortified church and destroy a radio transmitter. As the soldiers approach their target, they soon begin to realize that there's more going on in the Nazi-occupied village than a simple military operation. Making their way to an underground lab, the outnumbered men stumble upon a sinister experiment that forces them into a vicious battle against an army of the undead.",
                "https://www.themoviedb.org/t/p/w600_and_h900_bestv2/l76Rgp32z2UxjULApxGXAPpYdAP.jpg",
                "7.9/10"
            )
        )

        rMovies.add(
            MovieResponse(
                6,
                "Ralph Breaks the Internet (2018)",
                "Video game bad guy Ralph and fellow misfit Vanellope von Schweetz must risk it all by traveling to the World Wide Web in search of a replacement part to save Vanellope's video game, \"Sugar Rush.\" In way over their heads, Ralph and Vanellope rely on the citizens of the internet -- the netizens -- to help navigate their way, including an entrepreneur named Yesss, who is the head algorithm and the heart and soul of trend-making site BuzzzTube.",
                "https://www.themoviedb.org/t/p/w1280/44cb3fCGKUaSxxIjI2ejrgeYfye.jpg",
                "8.8/10"
            )
        )

        rMovies.add(
            MovieResponse(
                7,
                "Robin Hood (2018)",
                "After returning home to England, aristocrat Robin of Loxley learns that the evil Sheriff of Nottingham has seized his family estate. He soon joins forces with Friar Tuck and Little John -- a fierce Arabian warrior who wants to put an end to the Crusades. Armed with arrows and dubbed Robin Hood, Loxley leads a band of oppressed rebels in a daring plan to rob the Sheriff of his money and take away his power.",
                "https://www.themoviedb.org/t/p/w600_and_h900_bestv2/AiRfixFcfTkNbn2A73qVJPlpkUo.jpg",
                "5.3/10"
            )
        )

        rMovies.add(
            MovieResponse(
                8,
                "Serenity (2019)",
                "Baker Dill is a fishing boat captain who leads tours off of the tranquil enclave of Plymouth Island. His peaceful life is soon shattered when his ex-wife Karen tracks him down. Desperate for help, Karen begs Baker to save her -- and their young son -- from her abusive husband. She wants him to take the brute out for a fishing excursion -- then throw him overboard to the sharks. Thrust back into a life that he wanted to forget, Baker now finds himself struggling to choose between right and wrong.",
                "https://www.themoviedb.org/t/p/w600_and_h900_bestv2/hgWAcic93phg4DOuQ8NrsgQWiqu.jpg",
                "5.4/10"
            )
        )

        rMovies.add(
            MovieResponse(
                9,
                "Spider-Man: Into the Spider-Verse (2018)",
                "Bitten by a radioactive spider in the subway, Brooklyn teenager Miles Morales suddenly develops mysterious powers that transform him into the one and only Spider-Man. When he meets Peter Parker, he soon realizes that there are many others who share his special, high-flying talents. Miles must now use his newfound skills to battle the evil Kingpin, a hulking madman who can open portals to other universes and pull different versions of Spider-Man into our world.",
                "https://www.themoviedb.org/t/p/w600_and_h900_bestv2/nyXfGIkJQgKhugxMVql15URobtt.jpg",
                "9.7/10"
            )
        )

        rMovies.add(
            MovieResponse(
                10,
                "T-34 (2019)",
                "When a group of Russian soldiers are captured by the Nazis during World War II, they band together to plot and carry out a daring escape mission.",
                "https://www.themoviedb.org/t/p/w600_and_h900_bestv2/jqBIHiSglRfNxjh1zodHLa9E7zW.jpg",
                "6.7/10"
            )
        )

        return rMovies
    }

    fun generateRemoteDummyTvShows(): List<TvShowResponse> {
        val rTvShows = ArrayList<TvShowResponse>()

        rTvShows.add(
            TvShowResponse(
                1,
                "Iron Fist (season 1)",
                "Fueled by a desire for revenge, nine-year-old Danny Rand spent a decade training in martial arts in the heavenly city of K'un-Lun. He eventually earned the title of Iron Fist, granting him even more power. Instead of staying and embracing immortality, he returned to Earth ten years later to avenge his dead parents.",
                "13",
                "https://www.themoviedb.org/t/p/w600_and_h900_bestv2/4l6KD9HhtD6nCDEfg10Lp6C6zah.jpg"
            )
        )

        rTvShows.add(
            TvShowResponse(
                2,
                "Naruto: Shippuden (season 1)",
                "Naruto Uzumaki, Sakura Haruno and Sai reuniting with Sasuke Uchiha who seeks Naruto's power and suppresses the Nine-Tailed Fox within his subconscious. The first episode begins with Naruto returning home after two and a half years of training with Jiraiya, and seeing Sakura and Konohamaru, many people from the village congratulate him. Konohamaru and his fellows are on a mission and somehow successfully complete it. Jiraiya accompanies Naruto home and meets Tsunade who assigns Naruto and Sakura on their first mission, but first they must defeat someone to prove their growth and progress in the last two and a half years.",
                "32",
                "https://www.themoviedb.org/t/p/w600_and_h900_bestv2/zAYRe2bJxpWTVrwwmBc00VFkAf4.jpg"
            )
        )

        rTvShows.add(
            TvShowResponse(
                3,
                "NCIS (series)",
                "NCIS is an American police procedural drama television series, revolving around a fictional team of special agents from the Naval Criminal Investigative Service, which conducts criminal investigations involving the U.S. Navy and Marine Corps.",
                "412",
                "https://www.themoviedb.org/t/p/w600_and_h900_bestv2/fi8EvaWtL5CvoielOjjVvTr7ux3.jpg"
            )
        )

        rTvShows.add(
            TvShowResponse(
                4,
                "Riverdale",
                "Archie Andrews discovers his love for music, and his teacher. ... After a teenager was murdered within the town of Riverdale, a group of teenagers, the jock Archie, the girl next door Betty, the new girl Veronica and the outcast Jughead try to unravel the evils lurking within this seemingly innocent town.",
                "13",
                "https://www.themoviedb.org/t/p/w600_and_h900_bestv2/wRbjVBdDo5qHAEOVYoMWpM58FSA.jpg"
            )
        )

        rTvShows.add(
            TvShowResponse(
                5,
                "Shameless",
                "The first season of Shameless depicts the dysfunctional family of Frank Gallagher, a single, alcoholic, trashy father of six children in Chicago, Illinois. ... Often involved in the Gallagher's lives are their neighbors, Kevin and Veronica, who fake a marriage mid-season to obtain a substantial dowry.",
                "134",
                "https://www.themoviedb.org/t/p/w600_and_h900_bestv2/9akij7PqZ1g6zl42DQQTtL9CTSb.jpg"
            )
        )

        rTvShows.add(
            TvShowResponse(
                6,
                "Supergirl",
                "Kara Zor-El was sent to Earth from Krypton as a thirteen year old by her parents Zor-El and Alura. ... The series begins eleven years later when Kara is learning to embrace her own superhuman powers as a Kryptonian and has adopted the superheroine alias \"Supergirl\".",
                "113",
                "https://www.themoviedb.org/t/p/w600_and_h900_bestv2/zsaiq8ZclPuneuN7loLEbsh1ANJ.jpg"
            )
        )

        rTvShows.add(
            TvShowResponse(
                7,
                "Supernatural",
                "Supernatural is an American television series created by Eric Kripke. ... Starring Jared Padalecki as Sam Winchester and Jensen Ackles as Dean Winchester, the series follows the two brothers as they hunt demons, ghosts, monsters, and other supernatural beings.",
                "327",
                "https://www.themoviedb.org/t/p/w600_and_h900_bestv2/KoYWXbnYuS3b0GyQPkbuexlVK9.jpg"
            )
        )

        rTvShows.add(
            TvShowResponse(
                8,
                "The Simpsons",
                "The series is a satirical depiction of American life, epitomized by the Simpson family, which consists of Homer, Marge, Bart, Lisa, and Maggie. The show is set in the fictional town of Springfield and parodies American culture and society, television, and the human condition.",
                "703",
                "https://www.themoviedb.org/t/p/w600_and_h900_bestv2/zLudbPueg8CxGhMS2tyDh3p0TdK.jpg"
            )
        )

        rTvShows.add(
            TvShowResponse(
                9,
                "The Umbrella Academy",
                "A family of former child heroes, now grown apart, must reunite to continue to protect the world. ... Seven are adopted by Sir Reginald Hargreeves, a billionaire industrialist, who creates The Umbrella Academy and prepares his \"children\" to save the world. But not everything went according to plan.",
                "20",
                "https://www.themoviedb.org/t/p/w600_and_h900_bestv2/scZlQQYnDVlnpxFTxaIv2g0BWnL.jpg"
            )
        )

        rTvShows.add(
            TvShowResponse(
                10,
                "The Walking Dead",
                "The Walking Dead takes place after the onset of a worldwide zombie apocalypse. ... The series centers on sheriff's deputy Rick Grimes, who wakes up from a coma. While in a coma, the world has been taken over by walkers.",
                "153",
                "https://www.themoviedb.org/t/p/w600_and_h900_bestv2/rqeYMLryjcawh2JeRpCVUDXYM5b.jpg"
            )
        )

        return rTvShows
    }
}