package com.denaya.mymoviecatalogue.data.source

import androidx.lifecycle.LiveData
import com.denaya.mymoviecatalogue.data.source.local.entity.Movie
import com.denaya.mymoviecatalogue.data.source.local.entity.TvShow

interface MovieCatalogueDataSource {

    fun getAllMovies(): LiveData<List<Movie>>

    fun getAllTvShows(): LiveData<List<TvShow>>

    fun getMovieById(movieId: Int): LiveData<Movie>

    fun getTvShowById(tvShowId: Int): LiveData<TvShow>
}