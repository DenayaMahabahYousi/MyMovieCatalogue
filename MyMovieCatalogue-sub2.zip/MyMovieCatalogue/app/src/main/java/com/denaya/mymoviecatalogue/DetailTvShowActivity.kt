package com.denaya.mymoviecatalogue

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.lifecycle.ViewModelProvider
import com.bumptech.glide.Glide
import com.bumptech.glide.load.resource.bitmap.RoundedCorners
import com.denaya.mymoviecatalogue.data.source.local.entity.TvShow
import com.denaya.mymoviecatalogue.databinding.ActivityDetailTvShowBinding
import com.denaya.mymoviecatalogue.ui.tvshow.TvShowViewModel
import com.denaya.mymoviecatalogue.ui.viewmodel.ViewModelFactory

class DetailTvShowActivity : AppCompatActivity() {
    private lateinit var binding: ActivityDetailTvShowBinding

    companion object {
        const val EXTRA_MOVIE = "extra_movie"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityDetailTvShowBinding.inflate(layoutInflater)

        setContentView(binding.root)

        supportActionBar?.setDisplayHomeAsUpEnabled(true)

        val factory = ViewModelFactory.getInstance(this)
        val viewModel = ViewModelProvider(this, factory)[TvShowViewModel::class.java]

        val extras = intent.extras
        if (extras != null) {
            val movieId = extras.getInt(EXTRA_MOVIE, 0)

            binding.progressBar.visibility = View.VISIBLE
            viewModel.setSelectedTvShow(movieId)
            viewModel.getTvShow().observe(this, { tvShow ->
                binding.progressBar.visibility = View.GONE
                populateTvShow(tvShow)
            })
        }
    }

    private fun populateTvShow(show: TvShow) {
        binding.showTitle.text = show.showTitle
        binding.showEps.text = show.showEpisode
        binding.showDescription.text = show.showDescription

        Glide.with(this)
            .load(show.showPoster)
            .transform(RoundedCorners(25))
            .into(binding.showPoster)
    }

    fun shareBtn(view: View) {
        Toast.makeText(
            this@DetailTvShowActivity,
            "Shared!",
            Toast.LENGTH_SHORT
        ).show()
    }
}