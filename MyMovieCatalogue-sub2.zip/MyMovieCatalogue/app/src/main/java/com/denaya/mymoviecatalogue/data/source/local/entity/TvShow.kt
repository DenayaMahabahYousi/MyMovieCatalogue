package com.denaya.mymoviecatalogue.data.source.local.entity

import android.os.Parcelable
import kotlinx.parcelize.Parcelize

@Parcelize
data class TvShow(
    var showId: Int,
    var showTitle: String,
    var showDescription: String,
    var showEpisode: String,
    var showPoster: String
): Parcelable
