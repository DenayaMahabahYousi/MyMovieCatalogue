package com.denaya.mymoviecatalogue.data.source.remote.response

import android.os.Parcelable
import kotlinx.parcelize.Parcelize

@Parcelize
data class TvShowResponse (
    var showId: Int,
    var showTitle: String,
    var showDescription: String,
    var showEpisode: String,
    var showPoster: String
) : Parcelable