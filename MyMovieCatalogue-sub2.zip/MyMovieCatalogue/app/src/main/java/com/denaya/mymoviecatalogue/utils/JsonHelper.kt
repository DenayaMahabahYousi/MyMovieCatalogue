package com.denaya.mymoviecatalogue.utils

import android.content.Context
import com.denaya.mymoviecatalogue.data.source.remote.response.MovieResponse
import com.denaya.mymoviecatalogue.data.source.remote.response.TvShowResponse
import org.json.JSONException
import org.json.JSONObject
import java.io.IOException

class JsonHelper(private val context: Context) {

    private fun parsingFileToString(fileName: String): String? {
        return try {
            val `is` = context.assets.open(fileName)
            val buffer = ByteArray(`is`.available())
            `is`.read(buffer)
            `is`.close()
            String(buffer)

        } catch (ex: IOException) {
            ex.printStackTrace()
            null
        }
    }

    fun loadMovies(): List<MovieResponse> {
        val movieList = ArrayList<MovieResponse>()
        try {
            val responseObject = JSONObject(parsingFileToString("MovieResponses.json").toString())
            val listArray = responseObject.getJSONArray("movies")
            for (i in 0 until listArray.length()) {
                val movie = listArray.getJSONObject(i)

                val id = movie.getInt("movieId")
                val title = movie.getString("title")
                val description = movie.getString("description")
                val poster = movie.getString("poster")
                val rate = movie.getString("rate")

                val movieResponse = MovieResponse(id, title, description, poster, rate)
                movieList.add(movieResponse)
            }
        } catch (e: JSONException) {
            e.printStackTrace()
        }

        return movieList
    }

    fun loadTvShows(): List<TvShowResponse> {
        val tvList = ArrayList<TvShowResponse>()
        try {
            val responseObject = JSONObject(parsingFileToString("TvShowResponses.json").toString())
            val listArray = responseObject.getJSONArray("tvShows")
            for (i in 0 until listArray.length()) {
                val tvShow = listArray.getJSONObject(i)

                val id = tvShow.getInt("showId")
                val title = tvShow.getString("title")
                val description = tvShow.getString("description")
                val poster = tvShow.getString("poster")
                val episode = tvShow.getString("episode")

                val tvShowResponse = TvShowResponse(id, title, description, episode, poster)
                tvList.add(tvShowResponse)
            }
        } catch (e: JSONException) {
            e.printStackTrace()
        }

        return tvList
    }
}