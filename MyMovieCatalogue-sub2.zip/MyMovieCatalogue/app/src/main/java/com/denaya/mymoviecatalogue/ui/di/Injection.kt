package com.denaya.mymoviecatalogue.ui.di

import android.content.Context
import com.denaya.mymoviecatalogue.data.source.MovieCatalogueRepository
import com.denaya.mymoviecatalogue.data.source.remote.RemoteDataSource
import com.denaya.mymoviecatalogue.utils.JsonHelper

object Injection {
    fun provideRepository(context: Context): MovieCatalogueRepository {

        val remoteDataSource = RemoteDataSource.getInstance(JsonHelper(context))

        return MovieCatalogueRepository.getInstance(remoteDataSource)
    }
}