package com.denaya.mymoviecatalogue.ui.tvshow

import androidx.lifecycle.LiveData
import androidx.lifecycle.ViewModel
import com.denaya.mymoviecatalogue.data.source.MovieCatalogueRepository
import com.denaya.mymoviecatalogue.data.source.local.entity.TvShow
import com.denaya.mymoviecatalogue.utils.DataDummy

class TvShowViewModel (private val movieCatalogueRepository: MovieCatalogueRepository) : ViewModel() {

    private var tvShowId: Int = 0

    fun setSelectedTvShow(tvShowId: Int) {
        this.tvShowId = tvShowId
    }

    fun getTvShow(): LiveData<TvShow> = movieCatalogueRepository.getTvShowById(tvShowId)

    fun getAllTvShows(): LiveData<List<TvShow>> = movieCatalogueRepository.getAllTvShows()
}