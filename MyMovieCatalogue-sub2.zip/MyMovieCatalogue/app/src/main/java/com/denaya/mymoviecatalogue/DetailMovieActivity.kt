package com.denaya.mymoviecatalogue

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.lifecycle.ViewModelProvider
import com.bumptech.glide.Glide
import com.bumptech.glide.load.resource.bitmap.RoundedCorners
import com.denaya.mymoviecatalogue.data.source.local.entity.Movie
import com.denaya.mymoviecatalogue.databinding.ActivityDetailMovieBinding
import com.denaya.mymoviecatalogue.ui.movie.MovieViewModel
import com.denaya.mymoviecatalogue.ui.viewmodel.ViewModelFactory

class DetailMovieActivity : AppCompatActivity() {
    private lateinit var binding: ActivityDetailMovieBinding

    companion object {
        const val EXTRA_MOVIE = "extra_movie"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityDetailMovieBinding.inflate(layoutInflater)

        setContentView(binding.root)

        supportActionBar?.setDisplayHomeAsUpEnabled(true)

        val factory = ViewModelFactory.getInstance(this)
        val viewModel = ViewModelProvider(this, factory)[MovieViewModel::class.java]

        val extras = intent.extras
        if (extras != null) {
            val movieId = extras.getInt(EXTRA_MOVIE, 0)

            binding.progressBar.visibility = View.VISIBLE
            viewModel.setSelectedMovie(movieId)
            viewModel.getMovie().observe(this, { movie ->
                binding.progressBar.visibility = View.GONE
                populateMovie(movie)
            })
        }
    }

    private fun populateMovie(movie: Movie) {
        binding.movieTitle.text = movie.movieTitle
        binding.movieRate.text = movie.movieRate
        binding.movieDescription.text = movie.movieDescription

        Glide.with(this)
            .load(movie.moviePoster)
            .transform(RoundedCorners(25))
            .into(binding.moviePoster)
    }

    fun shareBtn(view: View) {
        Toast.makeText(
            this@DetailMovieActivity,
            "Shared!",
            Toast.LENGTH_SHORT
        ).show()
    }
}