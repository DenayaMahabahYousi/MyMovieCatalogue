package com.denaya.mymoviecatalogue.data.source.local.entity

import android.os.Parcelable
import kotlinx.parcelize.Parcelize

@Parcelize
data class Movie (
    var movieId: Int,
    var movieTitle: String,
    var movieDescription: String,
    var moviePoster: String,
    var movieRate: String
) : Parcelable
