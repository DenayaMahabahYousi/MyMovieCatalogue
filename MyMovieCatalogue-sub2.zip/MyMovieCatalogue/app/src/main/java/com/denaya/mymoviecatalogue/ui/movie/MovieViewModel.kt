package com.denaya.mymoviecatalogue.ui.movie

import androidx.lifecycle.LiveData
import androidx.lifecycle.ViewModel
import com.denaya.mymoviecatalogue.data.source.MovieCatalogueRepository
import com.denaya.mymoviecatalogue.data.source.local.entity.Movie
import com.denaya.mymoviecatalogue.utils.DataDummy

class MovieViewModel (private val movieCatalogueRepository: MovieCatalogueRepository) : ViewModel() {

    private var movieId: Int = 0

    fun setSelectedMovie(movieId: Int) {
        this.movieId = movieId
    }

    fun getMovie(): LiveData<Movie> = movieCatalogueRepository.getMovieById(movieId)

    fun getAllMovies(): LiveData<List<Movie>> = movieCatalogueRepository.getAllMovies()
}