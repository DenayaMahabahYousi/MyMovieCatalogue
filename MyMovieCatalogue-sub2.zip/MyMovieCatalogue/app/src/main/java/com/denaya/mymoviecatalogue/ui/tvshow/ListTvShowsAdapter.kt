package com.denaya.mymoviecatalogue.ui.tvshow

import android.content.Intent
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.bumptech.glide.request.RequestOptions
import com.denaya.mymoviecatalogue.DetailTvShowActivity
import com.denaya.mymoviecatalogue.data.source.local.entity.TvShow
import com.denaya.mymoviecatalogue.databinding.ItemRowBinding

class ListTvShowsAdapter: RecyclerView.Adapter<ListTvShowsAdapter.ListViewHolder>() {
    private var listTvShow = ArrayList<TvShow>()

    fun setTvShow(shows: List<TvShow>?) {
        if (shows == null) return
        this.listTvShow.clear()
        this.listTvShow.addAll(shows)
    }


    override fun onCreateViewHolder(viewGroup: ViewGroup, viewType: Int): ListViewHolder {
        val binding = ItemRowBinding.inflate(LayoutInflater.from(viewGroup.context), viewGroup, false)
        return ListViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ListViewHolder, position: Int) {
        holder.bind(listTvShow[position])
    }

    override fun getItemCount(): Int = listTvShow.size

    inner class ListViewHolder(private val binding: ItemRowBinding) : RecyclerView.ViewHolder(binding.root) {
        fun bind(show: TvShow) {
            with(binding){
                Glide.with(itemView.context)
                    .load(show.showPoster)
                    .apply(RequestOptions().override(55, 75))
                    .into(imgItemPhoto)
                tvItemTitle.text = show.showTitle
                tvItemDescription.text = show.showDescription

                itemView.setOnClickListener {
                    val intent = Intent(itemView.context, DetailTvShowActivity::class.java)
                    intent.putExtra(DetailTvShowActivity.EXTRA_MOVIE, show.showId)
                    itemView.context.startActivity(intent)
                }
            }
        }
    }
}